import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/Services/data.service';
import { ToDoClass } from 'src/app/Models/ToDoClass';

@Component({
  selector: 'app-todo-list',
  templateUrl: './todo-list.component.html',
  styleUrls: ['./todo-list.component.scss']
})
export class TodoListComponent implements OnInit {

  model = new ToDoClass();
  allElementsToDo: ToDoClass[] = [];

  constructor(private data:DataService) {
    console.log(data.ElementToDoList);
    this.allElementsToDo = data.ElementToDoList;
   }

  ngOnInit(): void {
  }

  isDataCorrect(){
    return this.model.ToDoElement;
  
  }
  save(){
    console.log("Saving",this.model);

    this.data.saveElementToDO(this.model);
    this.model = new ToDoClass();

  }

}
