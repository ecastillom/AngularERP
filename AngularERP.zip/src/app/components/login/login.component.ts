import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/Services/data.service';
import { Router } from '@angular/router';
import { SharedService } from 'src/app/Services/shared.service';
import { ThrowStmt } from '@angular/compiler';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {

  userName = "";
  Pass = "";
  allUsers = [];
  Found = false;
  Alert = true;


  constructor(private data: DataService, private router: Router, private shared: SharedService) {
    //Get all users
    this.allUsers = data.userList;

   }

  login(){
    // Travel The list of User
    // Compare each user credentials with values from the form
    
    for(let i=0; i< this.data.userList.length; i++){
      var user = this.allUsers[i];

      if(user.userName.toLowerCase() == this.userName.toLowerCase() && user.password == this.Pass){
        console.log("Login");
        this.Found = true;

        this.shared.isUserLoggedIn = true;
        this.shared.userName = user.userName;

        this.router.navigate(["/User/Register"]);
      }
    }

    if(!this.Found){
      this.Alert = false;
      console.error("Wrong User or Password");
    }

  }

}
