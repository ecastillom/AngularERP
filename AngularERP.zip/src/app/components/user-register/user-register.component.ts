import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/Models/user';
import { DataService } from 'src/app/Services/data.service';

@Component({
  selector: 'app-user-register',
  templateUrl: './user-register.component.html',
  styleUrls: ['./user-register.component.scss']
})
export class UserRegisterComponent implements OnInit {

  model = new User();
  retypePass = "";
  alertVisible = false;
  
  constructor(private data: DataService) {

   }

  ngOnInit() {
    console.log("User Register ngOnInit");
  }

  isDataCorrect(){
    return this.model.userName && this.model.email && this.model.password && this.model.password == this.retypePass;
  }

  save(){
    console.log("Saving", this.model);

    this.data.saveUser(this.model);

    //restart the object on memory
    this.model = new User();
    this.retypePass = "";

    this.alertVisible = true;
    setTimeout(() => this.alertVisible = false, 2000);

  }

}
