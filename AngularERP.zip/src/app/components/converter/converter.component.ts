import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-converter',
  templateUrl: './converter.component.html',
  styleUrls: ['./converter.component.scss']
})
export class ConverterComponent implements OnInit {

  gF = 0.0;
  gC = 0.0;

  constructor() { }

  ngOnInit(): void {
  }

  convertToC(){
    this.gC = (this.gF - 32) * 5/9;
  }

  convertToF(){
    this.gF = (this.gC * 9/5) + 32;
  }

}
