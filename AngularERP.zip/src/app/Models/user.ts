export class User {
    userName: string;
    email: string;
    password: string;

    firtsName: string;
    lastName: string;
    phoneNumber: string;
    maritalStatus: number;
    ssn: string;

}