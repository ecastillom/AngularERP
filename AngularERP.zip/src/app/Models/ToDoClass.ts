export class ToDoClass{
    ToDoElement: string;

}