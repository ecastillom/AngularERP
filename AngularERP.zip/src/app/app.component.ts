import { Component } from '@angular/core';
import { listLazyRoutes } from '@angular/compiler/src/aot/lazy_routes';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'ERP';
  MyName = "Efren Castillo"

  constructor(){
    console.log("Hola mundo!! I'm the constructor");

    var Name: string = "Efren Castillo";
    var Age: number = 29;
    var Found: boolean = false;
    var List: string[] = [];

    this.Hello(Name);

  }

  Hello(Name){
    console.log(Name);
  }

  Algo(){
    console.log("Button Pushado");
    this.title = "this is awesome!!";
  }




}
