import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainPageComponent } from './components/main-page/main-page.component';
import { ContactPageComponent } from './components/contact-page/contact-page.component';
import { ConverterComponent } from './components/converter/converter.component';
import { UserRegisterComponent } from './components/user-register/user-register.component';
import { UserListComponent } from './components/user-list/user-list.component';
import { TodoListComponent } from './components/todo-list/todo-list.component';
import { LoginComponent } from './components/login/login.component';


const routes: Routes = [
{
  path: '', component: MainPageComponent
},
{
  path:'Contact', component: ContactPageComponent
},
{
  path:'Converter', component: ConverterComponent
},
{
  path:'User/Register', component: UserRegisterComponent
},
{
  path:'User/List', component: UserListComponent
},
{
  path:'todo', component: TodoListComponent
},
{
  path:'Login', component: LoginComponent
}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
