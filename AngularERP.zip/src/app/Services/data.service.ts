import { Injectable } from '@angular/core';
import { User } from '../Models/user';
import {ToDoClass} from '../Models/ToDoClass';

@Injectable({
  providedIn: 'root'
})
export class DataService {


  userList: User[] = [];
  ElementToDoList: ToDoClass[] = [];

  constructor() {

    var admin = new User();
    admin.firtsName = "Admin";
    admin.lastName = "User";
    admin.userName = "Admin";
    admin.password = "12345";

    this.userList.push(admin);
   }

  saveUser(user){
    this.userList.push(user);
  }

  saveElementToDO(ElementToDo){
    this.ElementToDoList.push(ElementToDo);
  }
}
